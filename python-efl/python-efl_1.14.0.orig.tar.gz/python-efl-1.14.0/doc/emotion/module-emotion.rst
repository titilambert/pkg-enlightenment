
.. automodule:: efl.emotion
   :exclude-members: Emotion
