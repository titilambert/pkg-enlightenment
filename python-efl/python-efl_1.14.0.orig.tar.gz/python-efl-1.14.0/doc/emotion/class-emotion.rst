.. currentmodule:: efl.emotion

:class:`efl.emotion.Emotion` Class
==================================

.. autoclass:: efl.emotion.Emotion
