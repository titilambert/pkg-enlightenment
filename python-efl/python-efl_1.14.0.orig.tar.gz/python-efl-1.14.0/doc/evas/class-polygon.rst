.. currentmodule:: efl.evas

:class:`efl.evas.Polygon` Class
===============================

.. autoclass:: efl.evas.Polygon
