.. currentmodule:: efl.evas

:class:`efl.evas.Line` Class
============================

.. autoclass:: efl.evas.Line
