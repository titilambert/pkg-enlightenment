.. currentmodule:: efl.evas

:class:`efl.evas.Image` Class
=============================

.. autoclass:: efl.evas.Image


:class:`efl.evas.FilledImage` Class
===================================

.. autoclass:: efl.evas.FilledImage
