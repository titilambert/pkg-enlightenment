.. currentmodule:: efl.evas

:class:`efl.evas.Map` Class
============================

.. autoclass:: efl.evas.Map
