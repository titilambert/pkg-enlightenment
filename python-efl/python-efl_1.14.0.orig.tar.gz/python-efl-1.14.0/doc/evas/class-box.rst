.. currentmodule:: efl.evas

:class:`efl.evas.Box` Class
===========================

.. autoclass:: efl.evas.Box
