.. currentmodule:: efl.evas

:class:`efl.evas.Text` Class
============================

.. autoclass:: efl.evas.Text
