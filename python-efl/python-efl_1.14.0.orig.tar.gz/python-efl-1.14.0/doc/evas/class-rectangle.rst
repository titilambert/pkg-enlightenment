.. currentmodule:: efl.evas

:class:`efl.evas.Rectangle` Class
=================================

.. autoclass:: efl.evas.Rectangle
