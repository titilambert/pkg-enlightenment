.. currentmodule:: efl.evas

:class:`efl.evas.Smart` Class
==========================================

.. autoclass:: efl.evas.Smart

:class:`efl.evas.SmartObject` Class
===================================

.. autoclass:: efl.evas.SmartObject
