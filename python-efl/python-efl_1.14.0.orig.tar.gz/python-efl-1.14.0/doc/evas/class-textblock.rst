.. currentmodule:: efl.evas

:class:`efl.evas.Textblock` Class
=================================

.. autoclass:: efl.evas.Textblock
