.. currentmodule:: efl.evas

:class:`efl.evas.Object` Class
==============================

.. autoclass:: efl.evas.Object
    :inherited-members:
