.. currentmodule:: efl.evas

:class:`efl.evas.Canvas` Class
==============================

.. autoclass:: efl.evas.Canvas
    :inherited-members:
