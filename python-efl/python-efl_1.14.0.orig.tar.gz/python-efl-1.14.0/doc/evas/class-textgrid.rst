.. currentmodule:: efl.evas

:class:`efl.evas.Textgrid` Class
================================

.. autoclass:: efl.evas.Textgrid

.. autoclass:: efl.evas.TextgridCell
