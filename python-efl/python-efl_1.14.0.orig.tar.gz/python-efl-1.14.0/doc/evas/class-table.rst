.. currentmodule:: efl.evas

:class:`efl.evas.Table` Class
=============================

.. autoclass:: efl.evas.Table
