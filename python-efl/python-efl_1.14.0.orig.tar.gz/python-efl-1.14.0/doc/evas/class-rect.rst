.. currentmodule:: efl.evas

:class:`efl.evas.Rect` Class
============================

.. autoclass:: efl.evas.Rect
