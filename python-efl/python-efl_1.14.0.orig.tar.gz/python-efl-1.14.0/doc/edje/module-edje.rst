
.. automodule:: efl.edje
   :exclude-members: Edje
