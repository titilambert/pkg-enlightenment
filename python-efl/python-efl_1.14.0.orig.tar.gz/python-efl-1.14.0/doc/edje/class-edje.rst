.. currentmodule:: efl.edje

:class:`efl.edje.Edje` Class
============================

.. autoclass:: efl.edje.Edje
