.. currentmodule:: efl.ethumb


:class:`efl.ethumb_client.Client` Class
========================================

.. autoclass:: efl.ethumb_client.Client
