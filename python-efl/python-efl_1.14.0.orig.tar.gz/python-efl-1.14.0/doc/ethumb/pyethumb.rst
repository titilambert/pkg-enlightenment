.. currentmodule:: efl.ethumb

:class:`efl.ethumb.PyEthumb` Class
==================================

.. autoclass:: efl.ethumb.PyEthumb

.. currentmodule:: efl.ethumb

