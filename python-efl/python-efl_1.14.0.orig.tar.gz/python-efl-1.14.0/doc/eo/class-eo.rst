.. currentmodule:: efl.eo

:class:`efl.eo.Eo` Class
========================

.. autoclass:: efl.eo.Eo

