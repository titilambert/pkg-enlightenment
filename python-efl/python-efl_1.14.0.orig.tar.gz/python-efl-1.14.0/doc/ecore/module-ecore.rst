
.. automodule:: efl.ecore
   :exclude-members: Animator, AnimatorTimeline, Exe, FdHandler, FileDownload,
                     FileMonitor, IdleEnterer, IdleExiter, Idler, Poller,
                     Timer, EventExeAdd, EventExeData, EventExeDel
