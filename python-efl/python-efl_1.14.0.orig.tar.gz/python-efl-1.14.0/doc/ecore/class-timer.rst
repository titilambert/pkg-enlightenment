.. currentmodule:: efl.ecore

:class:`efl.ecore.Timer` Class
==============================

.. autoclass:: efl.ecore.Timer
