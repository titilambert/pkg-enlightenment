.. currentmodule:: efl.ecore

:class:`efl.ecore.Animator` Class
=================================

.. autoclass:: efl.ecore.Animator
