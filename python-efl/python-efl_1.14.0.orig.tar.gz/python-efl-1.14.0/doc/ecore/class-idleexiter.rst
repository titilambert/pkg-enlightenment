.. currentmodule:: efl.ecore

:class:`efl.ecore.IdleExiter` Class
===================================

.. autoclass:: efl.ecore.IdleExiter
