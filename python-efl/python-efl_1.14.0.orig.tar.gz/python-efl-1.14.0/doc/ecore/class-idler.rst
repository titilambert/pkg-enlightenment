.. currentmodule:: efl.ecore

:class:`efl.ecore.Idler` Class
==============================

.. autoclass:: efl.ecore.Idler
