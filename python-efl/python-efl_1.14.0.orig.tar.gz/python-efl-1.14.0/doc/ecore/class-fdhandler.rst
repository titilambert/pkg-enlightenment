.. currentmodule:: efl.ecore

:class:`efl.ecore.FdHandler` Class
==================================

.. autoclass:: efl.ecore.FdHandler
