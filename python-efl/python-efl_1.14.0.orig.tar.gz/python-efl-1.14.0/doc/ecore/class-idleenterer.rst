.. currentmodule:: efl.ecore

:class:`efl.ecore.IdleEnterer` Class
====================================

.. autoclass:: efl.ecore.IdleEnterer
