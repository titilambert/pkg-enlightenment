.. currentmodule:: efl.ecore

:class:`efl.ecore.FileDownload` Class
=====================================

.. autoclass:: efl.ecore.FileDownload
