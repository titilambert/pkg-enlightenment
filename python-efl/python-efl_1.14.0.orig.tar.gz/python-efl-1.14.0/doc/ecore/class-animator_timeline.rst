.. currentmodule:: efl.ecore

:class:`efl.ecore.AnimatorTimeline` Class
=========================================

.. autoclass:: efl.ecore.AnimatorTimeline
