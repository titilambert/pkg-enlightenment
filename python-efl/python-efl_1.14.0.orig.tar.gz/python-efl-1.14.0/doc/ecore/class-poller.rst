.. currentmodule:: efl.ecore

:class:`efl.ecore.Poller` Class
===============================

.. autoclass:: efl.ecore.Poller
