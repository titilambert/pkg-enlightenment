.. currentmodule:: efl.ecore

:class:`efl.ecore.Exe` Class
==============================

.. autoclass:: efl.ecore.Exe
.. autoclass:: efl.ecore.EventExeAdd
.. autoclass:: efl.ecore.EventExeDel
.. autoclass:: efl.ecore.EventExeData
