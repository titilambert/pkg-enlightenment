.. currentmodule:: efl.ecore

:class:`efl.ecore.FileMonitor` Class
=====================================

.. autoclass:: efl.ecore.FileMonitor
