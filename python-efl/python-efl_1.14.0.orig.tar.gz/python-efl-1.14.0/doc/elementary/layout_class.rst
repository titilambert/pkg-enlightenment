
.. automodule:: efl.elementary.layout_class
