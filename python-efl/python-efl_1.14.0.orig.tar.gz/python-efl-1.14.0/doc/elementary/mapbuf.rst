
.. automodule:: efl.elementary.mapbuf
