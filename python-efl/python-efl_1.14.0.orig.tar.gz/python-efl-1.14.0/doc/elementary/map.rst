
.. automodule:: efl.elementary.map
