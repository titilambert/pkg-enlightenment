
.. automodule:: efl.elementary.actionslider
