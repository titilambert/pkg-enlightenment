
.. automodule:: efl.elementary.innerwindow
