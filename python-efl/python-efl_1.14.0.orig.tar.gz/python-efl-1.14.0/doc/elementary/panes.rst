
.. automodule:: efl.elementary.panes
