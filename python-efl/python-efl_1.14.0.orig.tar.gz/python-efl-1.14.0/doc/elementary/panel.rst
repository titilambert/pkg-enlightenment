
.. automodule:: efl.elementary.panel
