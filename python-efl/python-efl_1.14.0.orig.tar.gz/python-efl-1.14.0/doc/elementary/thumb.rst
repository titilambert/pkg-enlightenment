
.. automodule:: efl.elementary.thumb
