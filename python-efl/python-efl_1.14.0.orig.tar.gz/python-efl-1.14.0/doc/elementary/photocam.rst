
.. automodule:: efl.elementary.photocam
