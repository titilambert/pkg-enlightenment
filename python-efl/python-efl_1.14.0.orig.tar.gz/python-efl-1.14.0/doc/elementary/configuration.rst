
.. automodule:: efl.elementary.configuration
