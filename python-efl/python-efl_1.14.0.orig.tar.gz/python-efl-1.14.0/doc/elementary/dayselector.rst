
.. automodule:: efl.elementary.dayselector
