
.. automodule:: efl.elementary.image
