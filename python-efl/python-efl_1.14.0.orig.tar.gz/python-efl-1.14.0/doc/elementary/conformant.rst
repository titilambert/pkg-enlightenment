
.. automodule:: efl.elementary.conformant
