
.. automodule:: efl.elementary.transit
