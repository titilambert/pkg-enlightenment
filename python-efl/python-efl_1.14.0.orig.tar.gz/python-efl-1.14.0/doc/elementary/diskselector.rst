
.. automodule:: efl.elementary.diskselector
