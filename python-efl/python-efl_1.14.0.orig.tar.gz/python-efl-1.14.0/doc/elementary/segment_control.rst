
.. automodule:: efl.elementary.segment_control
