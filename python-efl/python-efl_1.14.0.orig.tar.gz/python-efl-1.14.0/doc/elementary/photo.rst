
.. automodule:: efl.elementary.photo
