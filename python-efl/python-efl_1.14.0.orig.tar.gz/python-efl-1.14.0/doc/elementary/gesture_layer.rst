
.. automodule:: efl.elementary.gesture_layer
