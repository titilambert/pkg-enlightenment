
.. automodule:: efl.elementary.icon
