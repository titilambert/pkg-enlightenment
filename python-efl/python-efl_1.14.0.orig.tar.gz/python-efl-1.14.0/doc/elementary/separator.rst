
.. automodule:: efl.elementary.separator
