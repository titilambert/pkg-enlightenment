
.. automodule:: efl.elementary.object
