
.. automodule:: efl.elementary.table
