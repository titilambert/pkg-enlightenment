
.. automodule:: efl.elementary.colorselector
