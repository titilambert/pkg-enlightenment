
.. automodule:: efl.elementary.general
