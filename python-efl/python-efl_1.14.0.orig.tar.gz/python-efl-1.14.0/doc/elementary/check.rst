
.. automodule:: efl.elementary.check
