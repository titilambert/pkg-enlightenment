
.. automodule:: efl.elementary.label
