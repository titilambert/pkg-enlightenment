
.. automodule:: efl.elementary.systray
