
.. automodule:: efl.elementary.genlist
