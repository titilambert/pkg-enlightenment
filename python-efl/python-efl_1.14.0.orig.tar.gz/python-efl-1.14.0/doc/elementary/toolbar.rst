
.. automodule:: efl.elementary.toolbar
