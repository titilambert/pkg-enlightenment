
.. automodule:: efl.elementary.spinner
