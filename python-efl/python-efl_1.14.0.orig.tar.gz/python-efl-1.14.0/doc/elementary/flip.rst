
.. automodule:: efl.elementary.flip
