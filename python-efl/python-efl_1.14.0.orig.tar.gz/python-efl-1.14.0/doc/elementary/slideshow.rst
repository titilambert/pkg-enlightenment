
.. automodule:: efl.elementary.slideshow
