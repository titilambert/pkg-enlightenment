
.. automodule:: efl.elementary.object_item
