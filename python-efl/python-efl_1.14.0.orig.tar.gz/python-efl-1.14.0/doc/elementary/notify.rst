
.. automodule:: efl.elementary.notify
