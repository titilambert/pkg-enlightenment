
.. automodule:: efl.elementary.bubble
