
.. automodule:: efl.elementary.fileselector_entry
