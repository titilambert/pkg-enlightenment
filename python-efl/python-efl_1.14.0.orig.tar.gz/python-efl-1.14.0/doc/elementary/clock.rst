
.. automodule:: efl.elementary.clock
