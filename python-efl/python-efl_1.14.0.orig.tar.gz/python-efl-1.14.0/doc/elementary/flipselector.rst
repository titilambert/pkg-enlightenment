
.. automodule:: efl.elementary.flipselector
