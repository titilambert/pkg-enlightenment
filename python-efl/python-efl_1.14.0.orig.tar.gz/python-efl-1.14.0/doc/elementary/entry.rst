
.. automodule:: efl.elementary.entry
