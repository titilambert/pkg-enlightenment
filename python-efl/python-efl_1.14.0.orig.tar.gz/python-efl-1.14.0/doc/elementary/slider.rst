
.. automodule:: efl.elementary.slider
